<?php include 'head.php';?>

<div class="container">
    <div class="row">
        <div class="main col-sm-10">
        <div class="header col-sm-12">
            <h1 class="h1 col-sm-10">Browse Jobs</h1>
            <div class="side-header col-sm-2">
                <div class="contact-btn">contact</div>
                <div class="notification-btn">
                    <div class="fa fa-bell"></div>        
                </div>
            </div>
        </div>

        <div id="news " class="col-sm-12">

        
        </div>