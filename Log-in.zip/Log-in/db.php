<?php
/* Database connection settings*/ 

$host = 'jesp2136.iba-abakomp.dk';
$user = 'c1dbu1';
$pass = 'yv8h1HUAYt';
$db = 'c1db3';
$mysqli = new mysqli($host,$user,$pass,$db) or die($mysqli->error);


